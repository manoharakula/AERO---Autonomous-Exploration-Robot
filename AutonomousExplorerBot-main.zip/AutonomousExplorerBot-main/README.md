# ExplorerBot
 An autonomous Exploration Robot
